# simple-chart
A simple example of chart rendering using the HTML5 canvas object








